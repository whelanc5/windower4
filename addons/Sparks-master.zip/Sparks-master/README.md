# Sparks

Enables buying sparks equipment easier. **Please note I do not enable looping, this just skips the menus for one purchase only.**


Find a sparks NPC and stand near them, within 5' / talking distance and issue the command
//sparks buy <item>

ie

//sparks buy negoroshiki


**Uses Packets**


