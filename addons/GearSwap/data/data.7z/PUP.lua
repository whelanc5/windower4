function get_sets() 
	-- Commands in game
	-- /gs c changeTP  switches between the list of modes in tpModes, equips the gear and sets it to current aftercast set
	-- /gs c "setName" quips the gear set and sets it to current aftercast set
	-- /gs c deploy puts autodeploy on, when you engage it will cast deploy
	-- /gs c automaneuver turns on automaneuver, when maneuvers wear it recasts them
	--/ in my init file (windower/scripts/init.txt) f9 is bound to sent /gs c changeTP 
	
	
	include('cdhelper.lua')
    sets.precast = {}
	
	
	sets.precast.JA = {}
	
	
	
	deploy = false
	automaneuver = false
	tpModes = { "Acc", "Haste", "Pet", "Default"} -- These are the sets that will cycle Modes, just make sure the set matches the name here ex: sets.TP.Name will equip if "Name" is in this list
	dtModes = {"Default", "Magic", "Full"} --sets.DT.Mode
	wsModes = {"Default", "Acc"}  --sets.WS.Mode
	idleModes = {"Default", "Pet"}
	petModes = {"Default","Tank", "DD", "Hybrid"}
	sets.base = {head="Hizamaru Somen",neck="Lissome Necklace",
        ear1="Bladeborn Earring",ear2="Steelflash Earring",body="Rawhide Vest",hands="Ryuo Tekko",
        ring1="Rajas Ring",ring2="Epona's Ring", back="Visucius's Mantle",waist="Hurch'lan Sash",legs= hercLegsTA,
        feet= hercFeetTA}
	
	sets.WS = set_combine(sets.base,{ring1 = "Spiral Ring", waist = "Windbuffet Belt", neck="Shifting Necklace +1"})
	sets.WS.Default = set_combine(sets.base,{ring1 = "Spiral Ring", waist = "Windbuffet Belt"})
	sets.WS.Acc = set_combine(sets.base,{ring1 = "Spiral Ring", waist = "Hurch'lan Sash", body = "Hizamaru Haramaki", neck="Shifting Necklace +1"})
	
    sets.precast.WS = set_combine(sets.base,{ring1 = "Spiral Ring", waist = "Windbuffet Belt"})
	
	
	
	sets['Shijin Spiral'] = {ring1 = "Rajas Ring", Neck="Light Gorget" }

	
	
	sets['Victory Smite'] = {ring1 = "Rajas Ring", Neck="Light Gorget", waist = "Thunder Belt", legs= hercLegsCrit, feet = hercFeetCrit}

	
	sets['Stringing Pummel'] = {ring1 = "Spiral Ring", Neck="Soil Gorget", waist = "Soil Belt", legs= hercLegsCrit, feet = hercFeetCrit}

	
    sets.TP = set_combine(sets.base,{})
	
	sets.TP.Default = set_combine(sets.TP,{})
    sets.TP.Acc = set_combine(sets.TP,{ body = "Hizamaru Haramaki", legs = "Hizamaru Hizayoroi", neck="Shifting Necklace +1"})	
	sets.TP.Haste = set_combine(sets.TP,{waist="Windbuffet Belt"})	
    sets.TP.DT=  set_combine(sets.base,{neck="Twilight Torque", ring1="Dark Ring", ring2="Dark Ring" , back="Cheviot Cape"})
	sets.TP.Pet= set_combine(sets.base,{ring1="Thurandaut Ring"})	
	
	
    sets.precast.JA['Tactical Switch'] = {feet="Cirque Scarpe +2"}	
    sets.precast.JA['Repair'] = {feet="Foire Babouches +1", ammo="Automat. Oil +3", ear1 ="Guignol Earring"}	
	sets.precast.JA['Maintenance'] = {ammo="Automat. Oil +1"}
	sets.precast.JA['Overdrive'] = {body = "Pitre Tobe +1"}
	
	sets.precast.maneuver = {body="Cirque Farsetto +2", hands="Foire Dastanas +1", neck="Buffoon's Collar", back="Visucius's Mantle"}
	
	
	
	sets.DT = set_combine(sets.base,{neck="Twilight Torque", ring1="Dark Ring", ring2="Dark Ring", back="Cheviot Cape", head = "Naga Somen", hands = "Naga Tekko"})
    sets.DT.Default = set_combine(sets.base,{neck="Twilight Torque", ring1="Dark Ring", ring2="Dark Ring" , back="Cheviot Cape"})
	sets.DT.Magic  = set_combine(sets.base,{neck="Twilight Torque", ring1="Dark Ring", ring2="Dark Ring"})
	sets.DT.Full = sets.DT
    sets.aftercast.TP = sets.TP    
    sets.aftercast.Idle = set_combine(sets.TP.DT,{feet="Hermes' Sandals", body = "Hizamaru Haramaki"})
	
	sets.Idle.DT = set_combine(sets.DT,{feet="Hermes' Sandals"})
	sets.Idle.Default = set_combine(sets.DT,{feet="Hermes' Sandals", body = "Hizamaru Haramaki"})
	sets.Idle.Pet = sets.Pet
	
	
	
	
	sets.midcast.Pet = {}	
	sets.midcast.Pet.Cure = { }
	sets.midcast.Pet['Elemental Magic'] = {hands = "Naga Tekko", head ="Rawhide Mask", Ear1 = "Burana Earring", Feet = "Cirque Scarpe +2"}
	sets.midcast.Pet.WeaponSkill = set_combine(sets.TP.DD, {head= "Cirque Cappello +2",  hands = "Cirque Guanti +2", ear2 = "Burana Earring", body="Pitre Tobe +1", ring1="Thurandaut Ring", ear1="Domes. Earring", feet = "Naga Kyahan", legs = "Taeon Tights"})
	
	sets.Pet = set_combine(sets.base,{ring1="Thurandaut Ring"})	
	sets.Pet.Default = set_combine(sets.base,{ring1="Thurandaut Ring"})	
	sets.Pet.DD = set_combine(sets.Pet,{ body="Pitre Tobe +1",  feet="Naga Kyahan"})
	sets.Pet.FullDD = set_combine(sets.Pet,{head = "Taeon Chapeau", hands = "Foire Dastanas +1", back="Visucius's Mantle", body="Pitre Tobe +1", ring1="Thurandaut Ring", ear1="Domes. Earring", ear2="Burana Earring", feet = "Naga Kyahan", legs = "Taeon Tights"})
	sets.Pet.Hybrid = set_combine(sets.Pet,{ body="Pitre Tobe +1"})
	sets.Pet.DT = set_combine(sets.Pet,{neck="Twilight Torque", ring2="Dark Ring"})
	sets.Pet.Tank= set_combine(sets.Pet,{ear1="Handler's Earring +1", ear2="Handler's Earring", feet = "Rao Sune-Ate"})  	
	sets.Pet.Idle = set_combine(sets.DT,{ring1="Thurandaut Ring"})
	sets.Pet.Idle.DD = set_combine(sets.DT,{head = "Taeon Chapeau", hands = "Foire Dastanas +1", back="Visucius's Mantle", body="Pitre Tobe +1", ring1="Thurandaut Ring", ear1="Domes. Earring", ear2="Burana Earring", feet = "Naga Kyahan", legs = "Taeon Tights"})	
	sets.Pet.Idle.Tank = set_combine(sets.DT,{head = "Taeon Chapeau", hands = "Foire Dastanas +1", back="Visucius's Mantle", body="Pitre Tobe +1", ring1="Thurandaut Ring", ear1="Handler's Earring +1", ear2="Handler's Earring", feet = "Rao Sune-Ate"})
	
	
	send_command('input /macro book 1;wait .1;input /macro set 9')
end

