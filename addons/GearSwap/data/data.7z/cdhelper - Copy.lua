	tpModes = {"Acc"}
	dtModes = {}
	petModes = {}
	idleModes = S{}
	
	commands = S{"magicburst", "deploy", "automaneuver"}
	
	modes = S{"tpMode", "petMode", "DTmode"}
	
	tpNum = 1
	petNum= 1
	idleNum=1
	dtNum =1
	
    tpMode= tpModes[1]
	idleMode= idleModes[1]
	petMode= petModes[1]
	dtMode = dtModes[1]
	
	deploy = false
	automaneuver = false
	magicburst = false
	
	sets.TP = {} 
	sets.precast = {}
	sets.precast.Magic = {}
	sets.precast.TP ={}
	sets.precast.TP ={}
	sets.precast.JA = {}
	sets.aftercast = {}
	sets.midcast = {}
	sets.midcast.Magic = {}
	sets.DT = {}
	sets.DT.Normal = {}
	
	
	--------------------------------------------------------tables for commands--------------------------------------------------------------------------------
    petWeaponskills = S{"Slapstick", "Knockout", 
    "Chimera Ripper", "String Clipper",  "Cannibal Blade", "Bone Crusher", "String Shredder",
    "Arcuballista", "Daze", "Armor Piercer", "Armor Shatterer"}
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------
function precast(spell)
	
	if spell.action_type == 'Magic' then
		if spell.skill == 'Healing Magic' then
			equip(sets.precast.Magic.Healing )
			
		else		
			equip(sets.precast.Magic)
		end
	elseif sets.precast.JA[spell.english] then
        equip(sets.precast.JA[spell.english])
    elseif sets.precast[spell.english] then
        equip(sets.precast[spell.english])
    elseif spell.type=="WeaponSkill" then
        if sets.precast.WS[spell.english] then
			equip(sets.precast.WS[spell.english])
		else
			equip(sets.precast.WS)
		end
	
    elseif string.find(spell.english,'Maneuver')  then
		equip(sets.precast.maneuver)
	elseif string.find(spell.english,'Waltz')  then
		equip(sets.precast.Waltz)
    end
	
   end
	

function buff_change(name, gain)
	if not gain and automaneuver and string.find(name,'Maneuver') then --maneuver auto put back up if automaneuver is true
			add_to_chat(122,name)
			send_command(name)		
	
	end
end

function pet_midcast(spell)
 if petWeaponskills:contains(spell.english) then   --petWeaponskills equip 
   -- equip(sets.midcast.Pet.WeaponSkill) 
  end
end

function pet_aftercast(spell)   --put tp gear back on after pet
 if player.status =='Engaged' then
        equip(sets.aftercast.TP)
    else
        equip(sets.aftercast.Idle)
    end
  end



function aftercast(spell)
    if player.status =='Engaged' then
        equip(sets.aftercast.TP)
    else
        equip(sets.aftercast.Idle)
    end
end

sets.obi = {
    Fire = {waist="Karin Obi"},
    Earth = {waist="Dorin Obi"},
    Water = {waist="Suirin Obi"},
    Wind = {waist="Furin Obi"},
    Ice = {waist="Hyorin Obi"},
    Lightning = {waist="Rairin Obi"},
    Light = {waist="Korin Obi"},
    Dark = {waist="Anrin Obi"},
    }
storms = {
    Fire = "Firestorm",
    Earth = "Sandstorm",
    Water = "Rainstorm",
    Wind = "Windstorm",
    Ice = "Hailstorm",
    Lightning = "Thunderstorm",
  }


function midcast(spell)
	if sets.midcast[spell.english] then
        equip(sets.midcast[spell.english])	
	elseif  spell.action_type == 'Magic' then
		if spell.skill == 'Healing Magic' then
			equip(sets.midcast.Healing)				
		elseif spell.skill == 'Elemental Magic' then
			if magicburst then
				equip(sets.midcast.burst)
			else			
				equip(sets.midcast.Elemental)
			end
			storm = storms[spell.element]
			if spell.element == world.weather_element or spell.element == world.day_element or buffactive[storm]  then
				equip(sets.obi[spell.element])
			end
		end	
	end
end	

function status_change(new,old)
    if T{'Idle','Resting'}:contains(new) then
        equip(sets.aftercast.Idle)
    elseif new == 'Engaged' then
        equip(sets.aftercast.TP)
		if deploy == true then                          --deploys if deploy boolean is true
			send_command('@input /ja deploy <t>')
		end
    end
end

function booleanChange(bool)
	if bool == false then 
			return true					
	else 
		return false			
	end
end
 

function self_command(command)
	
	if modes:contains(command) then		--key bind for changing dt modes	
		add_to_chat(122, command.sub(command,0,2))
		str = command.sub(command,0,2)
		modesVar = _G[command .. "s"]
		--modeVar = _G[command]
		modesNum = _G[str .. "Num"]
		if  #modesVar == 0 then			
			
			equip(sets.TP[str])
			sets.aftercast.TP = sets.TP[str]
			add_to_chat(122, command)
		else
			if  modesNum == #modesVar then
				modesNum = 1 	
			else 
				modesNum = modesNum + 1
			end
			modeVar= modesVar[modesNum]
			_G[str .. "Num"] = modesNum
			sets.aftercast.TP = sets.TP[modeVar]
			equip(sets.TP[modeVar])
			add_to_chat(122, modeVar .. str)
		end
	end
	
	if command == 'c1' then		--key bind for changing dt modes	
		if  #dtModes == 0 then
			equip(sets.TP.DT)
			sets.aftercast.TP = sets.TP.DT
			add_to_chat(122, "dt")
		else
			if  dtNum == #dtModes then
				dtNum = 1 	
			else 
				dtNum = dtnum + 1
			end
			dtMode= dtModes[dtNum]
			sets.TP.DT  = sets.DT[dtMode]
			sets.aftercast.TP = sets.TP.DT
			equip(sets.TP[dtMode])
			add_to_chat(122, dtMode .. "DT")
		end
		
	elseif command == 'c2' then		--key bind for changing idle modes	
		if  #idleModes == 0 then
			equip(sets.aftercast.Idle)
			add_to_chat(122, "Idle")
		else
			if idleNum == #idleModes then
				idleNum = 1 
			else
				idleNum = idleNum + 1	
			end
			idleMode= idleModes[idleNum]
			sets.aftercast.Idle = sets.Idle[idleMode]
			equip(sets.Idle[idleMode])
			add_to_chat(122, idleMode .. "idle")			
		end
	elseif command == 'c3' then		-- for changing pet modes by hotkey, bound to f12	
		if  #petModes == 0 then
			
		else
			if petNum == #petModes then
				petNum = 1 
			else
				petNum = petNum + 1	
			end
				petMode= petModes[petNum]
				sets.aftercast.TP = sets.TP[petMode]
				equip(sets.TP[petMode])
				add_to_chat(122, petMode)	
		end
	elseif command == 'changeTP' then -- for changing tp modes by hotkey, bound to f9 in my init file
		if  #tpModes == 0 then
			
		else
			if tpNum == #tpModes then
				tpNum = 1 
			else		
				tpNum= tpNum + 1
			end
				tpMode= tpModes[tpNum]
				sets.aftercast.TP = sets.TP[tpMode]
				equip(sets.TP[tpMode])
				add_to_chat(122, tpMode)
		end	
	elseif sets.TP[command] then --for changing tp modes by direct command
		if sets.TP[command][tpmode] then
			sets.aftercast.TP = sets.TP[command]
			equip(sets.TP[command])
			add_to_chat(122,command)
		else
			sets.aftercast.TP = sets.TP[command]
			equip(sets.TP[command])
			add_to_chat(122,command .."-default" )
		end	
	elseif commands:contains(command) then		--turns on automaneuver
		_G[command] = booleanChange(_G[command])
		if _G[command] == true then
			add_to_chat(122, command .. " on")
		else 
			add_to_chat(122, command .. " off")
		end
    end
end	
    

		
    
	
