	tpModes = {"default", "Acc", "DT"}
	num = 1
    tpMode= tpModes[num]
	deploy = false
	automaneuver = false
	--------------------------------------------------------tables for commands--------------------------------------------------------------------------------
    petWeaponskills = S{"Slapstick", "Knockout", 
    "Chimera Ripper", "String Clipper",  "Cannibal Blade", "Bone Crusher", "String Shredder",
    "Arcuballista", "Daze", "Armor Piercer", "Armor Shatterer"}
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------
function precast(spell)
	if sets.precast.JA[spell.english] then
        equip(sets.precast.JA[spell.english])
     elseif sets.precast[spell.english] then
        equip(sets.precast[spell.english])
    elseif spell.type=="WeaponSkill" then
        equip(sets.precast.WS)
    elseif string.find(spell.english,'Maneuver')  then
		equip(sets.precast.maneuver)
    end
	
end
function buff_change(name, gain)
	if not gain and automaneuver and string.find(name,'Maneuver') then --maneuver auto put back up if automaneuver is true
			add_to_chat(122,name)
			send_command(name)		
	
	end
end

function pet_midcast(spell)
 if petWeaponskills:contains(spell.english) then   --petWeaponskills equip 
    equip(sets.midcast.Pet.WeaponSkill) 
  end
end

function pet_aftercast(spell)   --put tp gear back on after pet
 if player.status =='Engaged' then
        equip(sets.aftercast.TP)
    else
        equip(sets.aftercast.Idle)
    end
  end

function midcast(spell)
end

function aftercast(spell)
    if player.status =='Engaged' then
        equip(sets.aftercast.TP)
    else
        equip(sets.aftercast.Idle)
    end
end

function status_change(new,old)
    if T{'Idle','Resting'}:contains(new) then
        equip(sets.aftercast.Idle)
    elseif new == 'Engaged' then
        equip(sets.aftercast.TP)
		if deploy == true then                          --deploys if deploy boolean is true
			send_command('@input /ja deploy <t>')
		end
    end
end

function self_command(command)
	if command == 'c1' then		--key bind for .
		send_command('input /ja retrieve <me>')
	
	elseif command == 'changeTP' then
		if num == #tpModes then
			num = 1 
			tpMode= tpModes[num]
			sets.aftercast.TP = sets.TP[tpMode]
			equip(sets.TP[tpMode])
			add_to_chat(122, tpMode)
			
		else 
			num = num + 1
			tpMode= tpModes[num]
			sets.aftercast.TP = sets.TP[tpMode]
			equip(sets.TP[tpMode])
			add_to_chat(122, tpMode)
			
		end
		
	elseif sets.TP[command] then
		if sets.TP[command][tpmode] then
			sets.aftercast.TP = sets.TP[command]
			equip(sets.TP[command])
			add_to_chat(122,command)
		else
			sets.aftercast.TP = sets.TP[command]
			equip(sets.TP[command])
			add_to_chat(122,command .."-default" )
		end
	
	
	elseif command == 'deploy' then		--turns on autodeploy
		if deploy == false then 
			deploy = true
			send_command('@input /echo Autodeploy On')
		
	   	elseif deploy == true then 
			deploy = false
			send_command('@input /echo Autodeploy off')
		end	
		
    
	elseif command == 'automaneuver' then		--turns on automaneuver
		if automaneuver == false then 
			automaneuver = true
			send_command('@input /echo automaneuver On')
		
	   	elseif automaneuver == true then 
			automaneuver = false
			send_command('@input /echo automaneuver off')
		end	
		
    end
end	
    

		
    
	
