function get_sets()                
    sets.precast = {}        
	tpModes = {"default", "Acc", "DT"}
    tpmode= tpModes[1]
	
	
	sets.base = {head="Taeon Chapeau",neck="Shifting Necklace +1",
        ear1="Bladeborn Earring" ,ear2="Steelflash Earring",body="Taeon Tabard",hands="Taeon Gloves",
        ring1="Rajas Ring",ring2="Epona's Ring", back="Canny Cape",waist="Anguinus Belt",legs="Taeon Tights",
        feet="Herculean boots"}   
	
    sets.TP =  set_combine(sets.base,{})
		
    sets.TP.Acc = set_combine(sets.TP,{})
	 
    sets.TP.Haste = set_combine(sets.TP,{waist="Life Belt"})
	
	sets.TP.Haste.DT = set_combine(sets.TP,{neck="Twilight Torque"})
	
	sets.TP.th =  set_combine(sets.TP,{hands="Asn. Armlets +2",feet="Raid. Poulaines +2"})
	
	sets.TP.DT=  set_combine(sets.TP,{neck="Twilight Torque", ring1="Dark Ring", ring2="Dark Ring" })
	sets.precast.WS = set_combine(sets.base,{waist = "Windbuffet Belt"})
	
    sets.precast.JA = {} 
    sets.aftercast = {}
    sets.aftercast.TP = sets.TP
    
    sets.aftercast.Idle = set_combine(sets.TP.DT,{feet = "Trotter Boots"})
    send_command('input /macro book 2;wait .1;input /macro set 1')
end

function precast(spell)
	if sets.precast.JA[spell.english] then
        equip(sets.precast.JA[spell.english])
      elseif sets.precast[spell.english] then
        equip(sets.precast[spell.english])
    elseif spell.type=="WeaponSkill" then
        equip(sets.precast.WS)
    elseif string.find(spell.english,'Waltz') then
        equip(sets.precast.Waltz)
    end
end

function midcast(spell)
end

function aftercast(spell)
    if player.status =='Engaged' then
        equip(sets.aftercast.TP)
    else
        equip(sets.aftercast.Idle)
    end
end

function status_change(new,old)
    if T{'Idle','Resting'}:contains(new) then
        equip(sets.aftercast.Idle)
    elseif new == 'Engaged' then
        equip(sets.aftercast.TP)
    end
end

function self_command(command)
	
	if sets.TP[command] then
		if sets.TP[command][tpmode] then
			sets.aftercast.TP = sets.TP[command][tpmode]
			equip(sets.TP[command][tpmode])
			add_to_chat(122,command .. tpmode )
		else
			sets.aftercast.TP = sets.TP[command]
			equip(sets.TP[command])
			add_to_chat(122,command .. tpmode )
		end
	end
end